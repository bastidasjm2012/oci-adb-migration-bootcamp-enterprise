# Sample outputs

Guarda aqui salidas anonimizadas:

- `cpat_summary.txt`
- `adbping_report.txt`
- `expdp_blue_schemas.log`
- `impdp_sapphire_blue_schemas.log`
- `impdp_ruby_red_f1_network_link.log`
- `objects_summary_source.txt`
- `objects_summary_target.txt`
