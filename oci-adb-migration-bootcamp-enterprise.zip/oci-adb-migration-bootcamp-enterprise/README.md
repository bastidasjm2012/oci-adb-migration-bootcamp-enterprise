# Autonomous Database Migration Bootcamp - OCI Lab Repository

Repositorio enterprise para documentar y ejecutar un laboratorio de migracion hacia Oracle Autonomous Database usando Oracle Cloud Infrastructure, CPAT, Cloud Migration Advisor, Data Pump con NFS, Data Pump con database link, validacion post-migracion y Database Actions.

> Basado en el laboratorio **Autonomous Database Migration Bootcamp**. Este repositorio no reemplaza la guia oficial: organiza los pasos, scripts, evidencias y buenas practicas para publicarlo como proyecto tecnico en GitHub.

## Arquitectura del laboratorio

- **Origen:** Oracle Database 23ai / CDB23 con PDBs `BLUE` y `RED`.
- **Destino:** Autonomous Database Free Container / ADB con servicios `SAPPHIRE` y `RUBY`.
- **Migracion 1:** `BLUE` -> `SAPPHIRE` usando Data Pump con dump files compartidos por NFS.
- **Migracion 2:** `RED` -> `RUBY` usando Data Pump via database link.
- **Analisis:** CPAT y Cloud Migration Advisor.
- **Validacion:** conteo de objetos, conteo de filas, revision de logs, DBMS_COMPARISON y correccion de errores post-migracion.

## Estructura

```text
.
├── docs/                         # Guias paso a paso y runbooks
├── scripts/                      # Scripts Bash y SQL por fase
├── screenshots/                  # Capturas de evidencia del laboratorio
├── reports/sample_outputs/       # Plantillas para guardar salidas y logs
├── assets/                       # Diagramas y recursos del repositorio
├── CHANGELOG.md
├── LICENSE
└── README.md
```

## Ejecucion sugerida

1. Inicializar ambiente.
2. Ejecutar CPAT generico y CPAT especifico por metodo.
3. Usar CMA para confirmar estrategia.
4. Ejecutar ADBPing para revisar latencia.
5. Migrar `BLUE` hacia `SAPPHIRE` con Data Pump + NFS.
6. Migrar `RED` hacia `RUBY` con Data Pump + DB Link.
7. Validar migracion, corregir diferencias y documentar evidencias.
8. Revisar Database Actions: SQL, usuarios y Performance Hub.

## Buenas practicas incluidas

- Separacion por fases del laboratorio.
- Scripts idempotentes cuando aplica.
- Variables centralizadas.
- Logs por ejecucion.
- Checklist de evidencias para GitHub.
- Plantillas de README tecnico por fase.
- Validaciones pre y post-migracion.

## Nota de seguridad

No subas passwords reales, wallets, claves privadas, logs con datos sensibles ni OCIDs privados. Usa variables de entorno, archivos `.env.example` y capturas anonimizadas.
