# Changelog

## v1.0.0

- Estructura inicial del repositorio.
- Documentacion por fases.
- Scripts para ambiente, CPAT, Data Pump, validacion y Database Actions.
- Capturas representativas del PDF del laboratorio.
