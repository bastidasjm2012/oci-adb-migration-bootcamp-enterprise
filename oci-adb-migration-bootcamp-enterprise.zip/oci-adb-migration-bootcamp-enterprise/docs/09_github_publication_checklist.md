# 09 - Checklist para publicar en GitHub

## Antes de subir

- [ ] Eliminar passwords reales.
- [ ] Eliminar wallets ADB.
- [ ] Eliminar OCIDs privados.
- [ ] Anonimizar tenancy, usuarios, IPs y hostnames internos.
- [ ] Revisar capturas para no exponer informacion sensible.
- [ ] Confirmar que los scripts usan variables de entorno.
- [ ] Agregar screenshots representativas en `screenshots/`.
- [ ] Agregar logs anonimizados en `reports/sample_outputs/`.
- [ ] Validar que `README.md` explique objetivo, arquitectura y ejecucion.

## Comandos Git sugeridos

```bash
git init
git add .
git commit -m "Initial enterprise OCI ADB migration bootcamp repository"
git branch -M main
git remote add origin https://github.com/<user>/oci-adb-migration-bootcamp-enterprise.git
git push -u origin main
```
